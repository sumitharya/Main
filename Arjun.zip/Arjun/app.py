from flask import Flask, render_template, request, send_from_directory, redirect, url_for
import os
import pandas as pd
import json

app = Flask(__name__)

# Configure upload and edited directories
UPLOAD_FOLDER = 'uploads'
EDITED_FOLDER = 'edited'
ALLOWED_EXTENSIONS = {'xlsx', 'xls'}

# Ensure the upload and edited directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(EDITED_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['EDITED_FOLDER'] = EDITED_FOLDER

def allowed_file(filename):
    """Check if the file has an allowed Excel extension."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def upload_file():
    """Render the index page."""
    return render_template('index.html')

@app.route('/index.html')
def main():
    return render_template('index.html')

@app.route('/p2.html')
def part2():
    return render_template('p2.html')

@app.route('/p3.html')
def part3():
    return render_template('p3.html')

@app.route('/p4.html')
def part4():
    return render_template('p4.html')

@app.route('/p5.html')
def part5():
    return render_template('p5.html')

@app.route('/p6.html')
def part6():
    return render_template('p6.html')

@app.route('/p8.html')
def part8():
    return render_template('p8.html')

@app.route('/p9.html')
def part9():
    return render_template('p9.html')

@app.route('/p11.html')
def part11():
    return render_template('p11.html')

@app.route('/upload.html')
def upload():
    return render_template('upload.html')

@app.route('/edit.html')
def edit():
    return render_template('edit.html')

@app.route('/edit', methods=['POST'])
def edit_file():
    """Handle the uploaded file and display it for editing."""
    if 'file' not in request.files:
        return "No file part", 400
    file = request.files['file']
    if file.filename == '':
        return "No selected file", 400
    if file and allowed_file(file.filename):
        filename = file.filename
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)  # Save the uploaded file

        # Read the Excel file using Pandas
        df = pd.read_excel(filepath, sheet_name=0)
        
         # Replace NaN values with empty strings in the DataFrame
        df.fillna("", inplace=True)
        
         # Find columns or cells marked as "user input"
        editable_columns = [col for col in df.columns if "user input" in col.lower()]

        
        data = df.to_dict(orient='records')  # Convert to list of dictionaries

        # Pass the data and filename to the edit template
        return render_template('edit.html', data=data, filename=filename, columns=df.columns.tolist())
    else:
        return "Invalid file type. Please upload an Excel file.", 400


@app.route('/download', methods=['POST'])
def download_file():
    """Handle the edited data and provide the edited Excel file for download."""
    edited_data = request.form.get('edited_data')
    filename = request.form.get('filename')
    
    

    if not edited_data or not filename:
        return "Missing data or filename.", 400

    try:
        # Parse the JSON data received from the frontend
        data = json.loads(edited_data)
        df = pd.DataFrame(data)  # Convert back to DataFrame
        
         # Replace empty strings with NaN (if needed for saving) or leave them as empty
        df.replace("", None, inplace=True)

        # Save the edited DataFrame to an Excel file
        edited_filepath = os.path.join(app.config['EDITED_FOLDER'], filename)
        df.to_excel(edited_filepath, index=False)

        # Send the edited file for download
        return send_from_directory(directory=app.config['EDITED_FOLDER'],
                                   path=filename,
                                   as_attachment=True)
    except Exception as e:
        return f"An error occurred: {str(e)}", 500

if __name__ == '__main__':
    app.run(debug=True)
